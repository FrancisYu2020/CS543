To run the code for question 3, just run "python render_image.py"

To run the code for question 4, just run "python dynamic_perspective_starter.py"