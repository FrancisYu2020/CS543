There are three scripts in this submission.
combine.py is the response for question 3.1
reorder.py is the response for question 3.2
reorder_align.py is the response for question 3.3

Please put the given directory shredded-images in current directory so that all the scripts are runable.

To run any of the script, just use python SCRIPT_NAME.py, it will automatically iterate through the required directories and finish
the corresponding tasks. The generated images will be presented in the current directory.